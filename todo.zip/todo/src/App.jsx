import './App.css';
import Todo from './components/Todo';

function App() {
  return (
    <div className="App">
           <h1>React Redux Todo App</h1>
     <Todo />

    </div>
  );
}

export default App;
